export interface Movie {
    id: any;
    name: any;
    photo: any;
    duration: any;
    genres: any;
    year: any;
    info: any;

}
